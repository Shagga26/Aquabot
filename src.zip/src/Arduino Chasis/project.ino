#include "NeZha.h"
#include "Board_Timer.h"
#include "Vehicle_Chassis.h"
#include "ps2.h"
#include "LED.h"
#include "RobotArm.h" 

uint8_t Time;

void setup() {
  Serial.begin(9600);
  
  NeZha_Init();
  Vehicle_Chassis_Init(); 
  
  // Custom PS2 pins are loaded automatically from ps2.h
  PS2_Init(); 
  
  Board_Timer_Init();
  Led_Init();
  
  RobotArm_Init(); 

  Serial.println("System Ready. PS2 and Arm Active!");
}

void loop() {
  if (Board_Timer_Flag_Get())    
  {
    Time++;

    if ((Time + 1) % 5 == 0)     
    {
      PS2_ReadData(); // Get the latest states

      // ==========================================
      // 1. DRIVING LOGIC (Stays exactly the same)
      // ==========================================
      uint8_t leftY  = ps2_get_anolog_data(PSS_LY); 
      uint8_t rightX = ps2_get_anolog_data(PSS_RX); 

      if (leftY < 100)      { Vehicle_Chassis_Forward(200); }
      else if (leftY > 150) { Vehicle_Chassis_Backward(200); }
      else if (rightX < 100){ Vehicle_Chassis_TurnLeft(200); }
      else if (rightX > 150){ Vehicle_Chassis_TurnRight(200); }
      else                  { Vehicle_Chassis_Forward(0); }


      // ==========================================
      // 2. ROBOTIC ARM LOGIC (Shape Buttons)
      // ==========================================
      
      uint8_t armSpeed = 1; // 1 is slow and smooth. Change to 2 or 3 if it's too slow.

      // Arm Up and Down (Triangle / Cross)
      if (ps2_get_key_state(PSB_TRIANGLE)) {
        RobotArm_RaiseHand(armSpeed);
      }
      else if (ps2_get_key_state(PSB_CROSS)) { // Cross is the 'X' button
        RobotArm_DropHand(armSpeed);
      }

      // Arm Reach Forward and Backward (Circle / Square)
      if (ps2_get_key_state(PSB_CIRCLE)) {
        RobotArm_StretchHand(armSpeed);
      }
      else if (ps2_get_key_state(PSB_SQUARE)) {
        RobotArm_ShrinkHand(armSpeed);
      }

      // Claw Grip and Release (R1 / L1 Triggers)
      if (ps2_get_key_state(PSB_R1)) {
        RobotArm_ShakeHand(armSpeed); // Grip
      }
      else if (ps2_get_key_state(PSB_L1)) {
        RobotArm_LetHand(armSpeed);   // Release
      }

      // Reset Arm to Center Position (SELECT Button)
      if (ps2_get_key_state(PSB_SELECT)) {
        Robot_Arm_Reset();
      }
    }
    
    // Heartbeat LED
    if ((Time + 1) % 200 == 0) {
      Led_Turn();
    }
  } 
}
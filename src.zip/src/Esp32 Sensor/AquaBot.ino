#define BLYNK_TEMPLATE_ID "TMPL6jM9pc__u"
#define BLYNK_TEMPLATE_NAME "AQUABOT"
#define BLYNK_AUTH_TOKEN "KRU7nvykaSQILjgxv7oyCXasQCX_1Q_O"

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "jagatis's S25 FE";
char pass[] = "1234567890";

#define MOISTURE_PIN 34  
#define PH_PIN       32  
#define BUZZER_PIN   14  
#define GREEN_LED    25
#define YELLOW_LED   26
#define RED_LED      27

// --- Alert Thresholds & Calibration ---
#define PH_MIN 5.5
#define PH_MAX 8.5
float neutralVoltage = 2.90; // <-- YOUR EXACT pH 7.0 CALIBRATION VOLTAGE

LiquidCrystal_I2C lcd(0x27, 16, 2);
BlynkTimer timer;

BLYNK_CONNECTED() {
  Blynk.syncAll();
  Blynk.virtualWrite(V3, "Connected");
}

BLYNK_DISCONNECTED() {
  Blynk.virtualWrite(V3, "Disconnected");
}

void readSensors() {
  // --- 1. Moisture Reading ---
  int moistureRaw = analogRead(MOISTURE_PIN);
  int moisturePercent = map(moistureRaw, 3450, 1500, 0, 100);
  moisturePercent = constrain(moisturePercent, 0, 100);

  // --- 2. pH Reading ---
  int phRaw = analogRead(PH_PIN);
  float voltage = phRaw * (3.3 / 4095.0);
  
  // <-- UPDATED MATH USING YOUR CALIBRATION -->
  float phValue = 7.0 + ((neutralVoltage - voltage) / 0.18); 
  phValue = constrain(phValue, 0.0, 14.0);

  // --- 3. Update the LCD Display ---
  lcd.setCursor(0, 0);
  lcd.print("Moist:");
  lcd.print(moisturePercent);
  lcd.print("%       "); 

  lcd.setCursor(0, 1);
  lcd.print("pH: ");
  lcd.print(phValue, 1); 
  lcd.print("          "); 

  // --- 4. Logic & Alerts ---
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(YELLOW_LED, LOW);
  digitalWrite(RED_LED, LOW);
  
  String statusText = "";
  
  bool isDry = (moisturePercent <= 30);
  bool isPhBad = (phValue < PH_MIN || phValue > PH_MAX);

  if (isPhBad) {
    // CRITICAL: pH is out of bounds
    digitalWrite(RED_LED, HIGH);
    statusText = "pH WARNING!";
    
    // pH Buzzer Pattern: 3 Rapid Beeps
    for(int i = 0; i < 3; i++) {
      digitalWrite(BUZZER_PIN, HIGH);
      delay(50);
      digitalWrite(BUZZER_PIN, LOW);
      delay(50);
    }
  } 
  else if (isDry) {
    // WARNING: Soil is dry
    digitalWrite(RED_LED, HIGH); 
    statusText = "Dry - Alert!";
    
    // Moisture Buzzer Pattern: 1 Medium Beep
    digitalWrite(BUZZER_PIN, HIGH);
    delay(150);
    digitalWrite(BUZZER_PIN, LOW);
  } 
  else if (moisturePercent > 60) {
    // ALL GOOD: Wet
    digitalWrite(GREEN_LED, HIGH);
    statusText = "Wet / Optimal";
  } 
  else {
    // ACCEPTABLE: Medium
    digitalWrite(YELLOW_LED, HIGH);
    statusText = "Medium";
  }

  // --- 5. Send Data to Blynk Dashboard ---
  Blynk.virtualWrite(V0, moisturePercent); 
  Blynk.virtualWrite(V1, statusText);      
  Blynk.virtualWrite(V2, phValue);         
  Blynk.virtualWrite(V3, "Online");        
}

void setup() {
  Serial.begin(115200);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Wire.begin(18, 5); 

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("WiFi Connecting.");

  Blynk.begin(auth, ssid, pass);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("AQUABOT Online!");

  timer.setInterval(2000L, readSensors);
}

void loop() {
  Blynk.run();
  timer.run();
}